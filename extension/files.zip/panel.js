// panel.js — The Siphon (roll sync, unchanged behavior) + Marginalia (session notes)

// ─── Config ──────────────────────────────────────────────────────
const SUPABASE_URL = 'https://vtrtyagltwdrbastpppl.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZ0cnR5YWdsdHdkcmJhc3RwcHBsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzYzNTY5NTAsImV4cCI6MjA5MTkzMjk1MH0.hnpwjHGIqiUN_VmmIkOAAFGGCKsyYgl7AO3FW5vDIeM';
const DDB_USER_ID = 107965379;

const CAMPAIGNS = {
  'Sky Is The Limit':           { supabaseId: 1, gameId: 6907990, status: 'active' },
  'Pacts & Power':              { supabaseId: 2, gameId: 3661522, status: 'active' },
  'Ashfall Brittania':          { supabaseId: 3, gameId: 7170962, status: 'active' },
  'Where the Flowers Remember': { supabaseId: 4, gameId: 0,       status: 'paused' },
};

const NOTE_TYPES = [
  { id: 'moment',   label: 'Moment',   color: '#c89b3c' },
  { id: 'npc',      label: 'NPC',      color: '#6a8caf' },
  { id: 'quote',    label: 'Quote',    color: '#8fb0a0' },
  { id: 'quest',    label: 'Quest',    color: '#c9954a', tracksResolved: true },
  { id: 'question', label: 'Question', color: '#c17a7a', tracksResolved: true },
  { id: 'loot',     label: 'Loot',     color: '#a6935f' },
];

// ─── Logging (shared) ─────────────────────────────────────────────
const logEl = document.getElementById('log');

function log(msg, type = 'info') {
  const line = document.createElement('div');
  line.className = type;
  line.textContent = msg;
  logEl.appendChild(line);
  logEl.scrollTop = logEl.scrollHeight;
}

function clearLog() {
  logEl.innerHTML = '';
}

// ─── Siphon: campaign list ─────────────────────────────────────────
function renderCampaigns() {
  const container = document.getElementById('campaign-list');
  container.innerHTML = '';
  for (const [name, cfg] of Object.entries(CAMPAIGNS)) {
    const row = document.createElement('div');
    row.className = 'campaign-row';
    row.id = `campaign-${cfg.supabaseId}`;
    row.innerHTML = `
      <span class="name">${name}</span>
      <span class="badge ${cfg.status}">${cfg.status}</span>
      <span class="sync-status" id="status-${cfg.supabaseId}">—</span>
    `;
    container.appendChild(row);
  }
}

function setCampaignStatus(supabaseId, msg, type = 'info') {
  const el = document.getElementById(`status-${supabaseId}`);
  if (el) {
    el.textContent = msg;
    el.style.color = type === 'ok' ? '#4d4' : type === 'error' ? '#f66' : '#888';
  }
}

// ─── Siphon: token status ──────────────────────────────────────────
function updateTokenStatus(token, capturedAt) {
  const el = document.getElementById('token-status');
  const btn = document.getElementById('btn-sync-all');
  if (!token) {
    el.className = 'token-status warn';
    el.textContent = '⏳ No token yet — open any D&D Beyond page first.';
    btn.disabled = true;
  } else {
    const age = capturedAt ? Math.round((Date.now() - capturedAt) / 60000) : '?';
    el.className = 'token-status ok';
    el.textContent = `✅ Token captured (${age}m ago) — ready to sync.`;
    btn.disabled = false;
  }
}

// ─── Supabase helpers (shared by Siphon and Marginalia) ────────────
async function supabaseRequest(path, method, body) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
    method,
    headers: {
      'apikey': SUPABASE_KEY,
      'Authorization': `Bearer ${SUPABASE_KEY}`,
      'Content-Type': 'application/json',
      'Prefer': method === 'POST' ? 'resolution=merge-duplicates,return=minimal' : 'return=minimal',
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Supabase ${method} ${path}: ${res.status} ${err}`);
  }
  return res;
}

async function supabaseGet(path) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
    headers: { 'apikey': SUPABASE_KEY, 'Authorization': `Bearer ${SUPABASE_KEY}` },
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Supabase GET ${path}: ${res.status} ${err}`);
  }
  return res.json();
}

async function getLastSyncedUnix(campaignId) {
  const data = await supabaseGet(
    `ddb_rolls?campaign_id=eq.${campaignId}&select=timestamp_unix&order=timestamp_unix.desc&limit=1`
  );
  return data.length > 0 ? data[0].timestamp_unix : 0;
}

async function upsertRolls(rows) {
  // Collapse rows that share the composite conflict key. A single game-log
  // message can hold several rolls with the same rollId+rollType+notation, which
  // would make Postgres try to ON CONFLICT-update the same row twice in one
  // statement (error 21000). The unique constraint only keeps one such row
  // anyway, so we keep the last occurrence. Rows with a null dice_notation are
  // left as-is (NULLs are treated as distinct by the unique key).
  const byKey = new Map();
  const deduped = [];
  for (const r of rows) {
    if (r.dice_notation == null) { deduped.push(r); continue; }
    const key = `${r.campaign_id}|${r.roll_id}|${r.roll_type}|${r.dice_notation}`;
    if (byKey.has(key)) deduped[byKey.get(key)] = r;
    else { byKey.set(key, deduped.length); deduped.push(r); }
  }

  const BATCH = 500;
  let inserted = 0;
  for (let i = 0; i < deduped.length; i += BATCH) {
    const chunk = deduped.slice(i, i + BATCH);
    await supabaseRequest(
      'ddb_rolls?on_conflict=campaign_id,roll_id,roll_type,dice_notation',
      'POST',
      chunk
    );
    inserted += chunk.length;
    if (deduped.length > BATCH) {
      log(`  ↳ Upserted ${inserted}/${deduped.length} rolls...`);
    }
  }
  return inserted;
}

async function updateCampaignSync(campaignId, lastUnix) {
  const iso = new Date(lastUnix).toISOString();
  await supabaseRequest(
    `ddb_campaigns?id=eq.${campaignId}`,
    'PATCH',
    { last_synced_iso: iso, last_synced_unix: lastUnix }
  );
}

// ─── DDB API helpers ─────────────────────────────────────────────
async function fetchDDBRolls(gameId, bearerToken, afterUnix = 0) {
  const messages = [];
  let lastEvaluatedKey = null;
  let page = 0;
  let done = false;

  while (!done) {
    page++;
    log(`  ↳ Fetching page ${page}...`);
    let url = `https://game-log-rest-live.dndbeyond.com/v1/getmessages?gameId=${gameId}&userId=${DDB_USER_ID}`;
    if (lastEvaluatedKey) url += `&lastEvaluatedKey=${encodeURIComponent(lastEvaluatedKey)}`;

    const res = await fetch(url, {
      headers: { 'Authorization': `Bearer ${bearerToken}` },
    });

    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`DDB API error: ${res.status} ${errText}`);
    }

    const json = await res.json();
    const batch = json.data || [];
    if (batch.length === 0) break;

    for (const msg of batch) {
      const ts = parseInt(msg.dateTime, 10) || 0;
      if (ts <= afterUnix) { done = true; break; }
      if (msg.eventType === 'dice/roll/fulfilled' && msg.data?.rolls?.length) {
        messages.push(msg);
      }
    }

    const nextKey = json.lastKey?.dateTime_eventType_userId || null;
    if (!nextKey) break;
    lastEvaluatedKey = nextKey;
    if (page > 300) { log('  ⚠️ Hit 300 page limit', 'warn'); break; }
    await new Promise(r => setTimeout(r, 250));
  }

  return messages;
}

function buildDiceNotation(dn) {
  if (!dn) return null;
  const parts = (dn.set || []).map(s => {
    const die = s.dieType || (s.dice && s.dice[0] && s.dice[0].dieType) || '';
    const count = s.count || (s.dice ? s.dice.length : 1);
    return `${count}${die}`;
  });
  let notation = parts.join('+');
  const c = dn.constant || 0;
  if (c > 0) notation += `+${c}`;
  else if (c < 0) notation += `${c}`;
  return notation || null;
}

function normalizeMessage(msg, campaignId) {
  const ts = parseInt(msg.dateTime, 10) || 0;
  const d = msg.data || {};
  const ctx = d.context || {};
  const base = {
    campaign_id: campaignId,
    timestamp_iso: new Date(ts).toISOString(),
    timestamp_unix: ts,
    character: ctx.name || null,
    user_id: msg.userId ? parseInt(msg.userId, 10) : null,
    action: d.action || 'custom',
    source: (msg.source || 'web').toLowerCase(),
    set_id: d.setId || null,
    roll_id: d.rollId || msg.id || null,
  };
  return (d.rolls || []).map(r => ({
    ...base,
    roll_type: r.rollType || 'roll',
    roll_kind: r.rollKind || '',
    dice_notation: buildDiceNotation(r.diceNotation),
    modifier: (r.diceNotation && r.diceNotation.constant) || 0,
    total: r.result?.total ?? null,
    individual_values: r.result?.values ? JSON.stringify(r.result.values) : null,
  }));
}

// ─── Sync logic ──────────────────────────────────────────────────
async function syncCampaign(campaignName, bearerToken) {
  const cfg = CAMPAIGNS[campaignName];
  if (cfg.status !== 'active') {
    setCampaignStatus(cfg.supabaseId, 'skipped');
    return;
  }
  if (!cfg.gameId || cfg.gameId === 0) {
    log(`❌ No gameId for "${campaignName}"`, 'error');
    setCampaignStatus(cfg.supabaseId, 'no gameId', 'error');
    return;
  }

  log(`\n🎲 ${campaignName}`, 'head');
  setCampaignStatus(cfg.supabaseId, 'syncing…');

  try {
    const lastUnix = await getLastSyncedUnix(cfg.supabaseId);
    if (lastUnix > 0) {
      log(`  ↳ Last sync: ${new Date(lastUnix).toISOString()}`);
    } else {
      log('  ↳ Full sync (no existing data)');
    }

    const rawRolls = await fetchDDBRolls(cfg.gameId, bearerToken, lastUnix);
    log(`  ↳ ${rawRolls.length} new rolls found`);

    if (rawRolls.length === 0) {
      log('  ✅ Already up to date', 'ok');
      setCampaignStatus(cfg.supabaseId, 'up to date', 'ok');
      return;
    }

    const rows = rawRolls.flatMap(m => normalizeMessage(m, cfg.supabaseId));
    const count = await upsertRolls(rows);
    const maxUnix = Math.max(...rows.map(r => r.timestamp_unix));
    await updateCampaignSync(cfg.supabaseId, maxUnix);

    log(`  ✅ Synced ${count} rolls`, 'ok');
    setCampaignStatus(cfg.supabaseId, `+${count}`, 'ok');
  } catch (e) {
    log(`  ❌ ${e.message}`, 'error');
    setCampaignStatus(cfg.supabaseId, 'error', 'error');
  }
}

async function syncAll(bearerToken) {
  const btn = document.getElementById('btn-sync-all');
  btn.disabled = true;
  btn.textContent = '⏳ Syncing…';
  clearLog();
  log('══════════════════════════════', 'head');
  log('DDB Roll Sync → Supabase', 'head');
  log('══════════════════════════════', 'head');

  for (const name of Object.keys(CAMPAIGNS)) {
    await syncCampaign(name, bearerToken);
  }

  log('\n🏁 Sync complete!', 'ok');
  btn.disabled = false;
  btn.textContent = '⚡ Sync All Campaigns';
}

// ─── Marginalia: session notes ─────────────────────────────────────
let activeCampaignId = null;
let sessionLabel = '';
let activeNoteType = 'moment';
const characterCache = {}; // campaignId -> [names]

function escapeHtml(s) {
  const div = document.createElement('div');
  div.textContent = s;
  return div.innerHTML;
}

async function fetchCharacterSuggestions(campaignId) {
  if (characterCache[campaignId]) return characterCache[campaignId];
  try {
    const rows = await supabaseGet(
      `ddb_rolls?campaign_id=eq.${campaignId}&select=character&character=not.is.null&limit=1000`
    );
    const names = [...new Set(rows.map(r => r.character).filter(Boolean))].sort();
    characterCache[campaignId] = names;
    return names;
  } catch (e) {
    log(`  ⚠️ Couldn't load character list: ${e.message}`, 'warn');
    return [];
  }
}

async function populateWhoList(campaignId) {
  const names = await fetchCharacterSuggestions(campaignId);
  const datalist = document.getElementById('who-suggestions');
  datalist.innerHTML = names.map(n => `<option value="${escapeHtml(n)}"></option>`).join('');
}

function noteTypeById(id) {
  return NOTE_TYPES.find(t => t.id === id) || NOTE_TYPES[0];
}

function renderNotesFeed(rows) {
  const feed = document.getElementById('notes-feed');
  if (rows.length === 0) {
    feed.innerHTML = '<span class="info">No notes yet this sitting.</span>';
    return;
  }
  feed.innerHTML = rows.map(r => {
    const type = noteTypeById(r.note_type);
    const whoTag = r.who ? `<span class="note-who">${escapeHtml(r.who)}</span>` : '';
    const resolvedTag = type.tracksResolved
      ? `<span class="note-resolved ${r.resolved ? 'yes' : 'no'}">${r.resolved ? '✓ resolved' : 'open'}</span>`
      : '';
    const delBtn = `<button class="note-del" data-id="${r.id}" title="Delete">×</button>`;
    return `
      <div class="note-row" style="border-left-color:${type.color}">
        <div class="note-head">
          <span class="note-type" style="color:${type.color}">${type.label}</span>
          ${whoTag}${resolvedTag}${delBtn}
        </div>
        <div class="note-body">${escapeHtml(r.content)}</div>
      </div>`;
  }).join('');
  feed.querySelectorAll('.note-del').forEach(btn => {
    btn.addEventListener('click', () => deleteNote(btn.dataset.id));
  });
}

async function loadNotesForSitting() {
  const feed = document.getElementById('notes-feed');
  if (!activeCampaignId) { feed.innerHTML = ''; return; }
  feed.innerHTML = '<span class="info">Loading…</span>';
  try {
    let path = `session_notes?campaign_id=eq.${activeCampaignId}&order=timestamp_unix.asc`;
    if (sessionLabel) path += `&session_label=eq.${encodeURIComponent(sessionLabel)}`;
    const rows = await supabaseGet(path);
    renderNotesFeed(rows);
  } catch (e) {
    feed.innerHTML = `<span class="error">Couldn't load notes: ${e.message}. Did you run the session_notes SQL yet?</span>`;
  }
}

async function addNote() {
  const contentEl = document.getElementById('note-content');
  const whoEl = document.getElementById('note-who');
  const content = contentEl.value.trim();

  if (!content) { log('  ⚠️ Note is empty', 'warn'); return; }
  if (!activeCampaignId) { log('  ❌ Pick a campaign first', 'error'); return; }

  const type = noteTypeById(activeNoteType);
  const who = whoEl.value.trim() || null;
  const resolved = type.tracksResolved ? document.getElementById('note-resolved').checked : null;
  const now = Date.now();

  const row = {
    campaign_id: activeCampaignId,
    session_label: sessionLabel || null,
    note_type: activeNoteType,
    content,
    who,
    resolved,
    timestamp_iso: new Date(now).toISOString(),
    timestamp_unix: now,
  };

  try {
    await supabaseRequest('session_notes', 'POST', row);
    contentEl.value = '';
    whoEl.value = '';
    log(`  📝 ${type.label} noted`, 'ok');
    loadNotesForSitting();
  } catch (e) {
    log(`  ❌ ${e.message}. Did you run the session_notes SQL yet?`, 'error');
  }
}

async function deleteNote(id) {
  try {
    await supabaseRequest(`session_notes?id=eq.${id}`, 'DELETE');
    loadNotesForSitting();
  } catch (e) {
    log(`  ❌ Couldn't delete note: ${e.message}`, 'error');
  }
}

function updateResolvedVisibility() {
  const type = noteTypeById(activeNoteType);
  document.getElementById('resolved-row').style.display = type.tracksResolved ? 'flex' : 'none';
}

function renderNoteTypeTabs() {
  const container = document.getElementById('note-type-tabs');
  container.innerHTML = NOTE_TYPES.map(t =>
    `<button class="type-tab ${t.id === activeNoteType ? 'active' : ''}" data-type="${t.id}" style="--tab-color:${t.color}">${t.label}</button>`
  ).join('');
  container.querySelectorAll('.type-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      activeNoteType = btn.dataset.type;
      renderNoteTypeTabs();
      updateResolvedVisibility();
    });
  });
}

function initMarginalia() {
  const campaignSelect = document.getElementById('note-campaign');
  campaignSelect.innerHTML = Object.entries(CAMPAIGNS)
    .map(([name, cfg]) => `<option value="${cfg.supabaseId}">${name}</option>`).join('');

  chrome.storage.local.get(['marginalia_campaign', 'marginalia_session'], (r) => {
    activeCampaignId = r.marginalia_campaign || CAMPAIGNS[Object.keys(CAMPAIGNS)[0]].supabaseId;
    sessionLabel = r.marginalia_session || '';
    campaignSelect.value = activeCampaignId;
    document.getElementById('note-session').value = sessionLabel;
    populateWhoList(activeCampaignId);
    loadNotesForSitting();
  });

  campaignSelect.addEventListener('change', () => {
    activeCampaignId = parseInt(campaignSelect.value, 10);
    chrome.storage.local.set({ marginalia_campaign: activeCampaignId });
    populateWhoList(activeCampaignId);
    loadNotesForSitting();
  });

  document.getElementById('note-session').addEventListener('change', (e) => {
    sessionLabel = e.target.value.trim();
    chrome.storage.local.set({ marginalia_session: sessionLabel });
    loadNotesForSitting();
  });

  renderNoteTypeTabs();
  updateResolvedVisibility();
  document.getElementById('btn-add-note').addEventListener('click', addNote);
}

// ─── Init ────────────────────────────────────────────────────────
renderCampaigns();

chrome.storage.local.get(['ddb_bearer_token', 'ddb_token_captured_at'], (result) => {
  updateTokenStatus(result.ddb_bearer_token, result.ddb_token_captured_at);
});

document.getElementById('btn-sync-all').addEventListener('click', () => {
  chrome.storage.local.get(['ddb_bearer_token'], (result) => {
    if (!result.ddb_bearer_token) {
      log('❌ No token — open a D&D Beyond page first.', 'error');
      return;
    }
    syncAll(result.ddb_bearer_token);
  });
});

document.getElementById('btn-clear-log').addEventListener('click', clearLog);

initMarginalia();
